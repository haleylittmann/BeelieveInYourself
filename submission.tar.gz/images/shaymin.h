/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 shaymin shaymin.png 
 * Time-stamp: Tuesday 11/20/2018, 01:12:58
 * 
 * Image Information
 * -----------------
 * shaymin.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SHAYMIN_H
#define SHAYMIN_H

extern const unsigned short shaymin[225];
#define SHAYMIN_SIZE 450
#define SHAYMIN_LENGTH 225
#define SHAYMIN_WIDTH 15
#define SHAYMIN_HEIGHT 15

#endif

