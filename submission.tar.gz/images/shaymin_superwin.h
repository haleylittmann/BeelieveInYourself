/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 240x160 shaymin_superwin shaymin_superwin.png 
 * Time-stamp: Sunday 11/18/2018, 21:12:20
 * 
 * Image Information
 * -----------------
 * shaymin_superwin.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SHAYMIN_SUPERWIN_H
#define SHAYMIN_SUPERWIN_H

extern const unsigned short shaymin_superwin[38400];
#define SHAYMIN_SUPERWIN_SIZE 76800
#define SHAYMIN_SUPERWIN_LENGTH 38400
#define SHAYMIN_SUPERWIN_WIDTH 240
#define SHAYMIN_SUPERWIN_HEIGHT 160

#endif

