/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=12x12 bee bee.png 
 * Time-stamp: Tuesday 11/20/2018, 01:11:55
 * 
 * Image Information
 * -----------------
 * bee.png 12@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEE_H
#define BEE_H

extern const unsigned short bee[144];
#define BEE_SIZE 288
#define BEE_LENGTH 144
#define BEE_WIDTH 12
#define BEE_HEIGHT 12

#endif

