/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 losingscreen losingscreen.png 
 * Time-stamp: Tuesday 11/13/2018, 06:05:09
 * 
 * Image Information
 * -----------------
 * losingscreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSINGSCREEN_H
#define LOSINGSCREEN_H

extern const unsigned short losingscreen[38400];
#define LOSINGSCREEN_SIZE 76800
#define LOSINGSCREEN_LENGTH 38400
#define LOSINGSCREEN_WIDTH 240
#define LOSINGSCREEN_HEIGHT 160

#endif

