/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 startscreentext startscreentext.png 
 * Time-stamp: Monday 11/12/2018, 21:01:53
 * 
 * Image Information
 * -----------------
 * startscreentext.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTSCREENTEXT_H
#define STARTSCREENTEXT_H

extern const unsigned short startscreentext[38400];
#define STARTSCREENTEXT_SIZE 76800
#define STARTSCREENTEXT_LENGTH 38400
#define STARTSCREENTEXT_WIDTH 240
#define STARTSCREENTEXT_HEIGHT 160

#endif

