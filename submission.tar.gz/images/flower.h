/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=9x9 flower flower.png 
 * Time-stamp: Saturday 11/17/2018, 22:04:30
 * 
 * Image Information
 * -----------------
 * flower.png 9@9
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLOWER_H
#define FLOWER_H

extern const unsigned short flower[81];
#define FLOWER_SIZE 162
#define FLOWER_LENGTH 81
#define FLOWER_WIDTH 9
#define FLOWER_HEIGHT 9

#endif

