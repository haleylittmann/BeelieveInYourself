/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize 240x160 control_adv control_adv.png 
 * Time-stamp: Sunday 11/18/2018, 21:17:54
 * 
 * Image Information
 * -----------------
 * control_adv.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CONTROL_ADV_H
#define CONTROL_ADV_H

extern const unsigned short control_adv[38400];
#define CONTROL_ADV_SIZE 76800
#define CONTROL_ADV_LENGTH 38400
#define CONTROL_ADV_WIDTH 240
#define CONTROL_ADV_HEIGHT 160

#endif

