STORY
Welcome to Beelieve in Yourself! Play as Shaymin and eat all the flowers to win the game.
Watch out though! The bees might also eat the flowers if they come near them. If you're lucky, they will
leave visible parts behind that you can collect. If they eat the whole flower, then you can try to remember the location
to look for scraps. Never fear if you can't find some! There are two more endings you can achieve.
The bees may be friendly or mean. Friendly bees will be happy to aid you on your journey, and you'll unlock
a super special winning screen. But mean bees will kill you.


"I don't think there's any story worth dying for, but I do think there are stories worth taking risks for."
(Anthony Shadid)


CONTROLS
D-Pad = Arrow keys (move Shaymin)
Select = Backspace (return to start screen at any point in the game)
Start = Enter (continue to the game from the start and control screens)

(All images and quotes are from Google)
